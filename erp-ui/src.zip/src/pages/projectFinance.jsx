import React, { useEffect, useState } from "react";

import Sidebar from "../components/Project Finance/Sidebar";
import Workspace from "../components/Project Finance/Workspace";
import AssetSidebar from "../components/Project Finance/AssetSidebar";

import "../styles/ProjectFinance.css";

import {
    getProjects,
    getProject,
    analyzeSavedProject, saveProject, updateProject, analyzeProject
} from "../services/api";

export default function ProjectFinance() {

    const [projects, setProjects] = useState([]);

    const [project, setProject] = useState({

    name: "",

    project_type: "solar",

    project_life: 25,

    tax_rate: 30,

    discount_rate: 10,

    debt_amount: 0,

    interest_rate: 10,

    loan_tenor: 10,

    construction_period_months: 12,

    moratorium_months: 0,

    repayment_frequency: "Monthly",

    repayment_type: "Equal Principal",

    interest_type: "Fixed",

    interest_capitalized: false,

    debt_drawdowns: [
        {
            year: 1,
            drawdown_months: 1,
            drawdown_amount: 0
        }
    ],

    depreciation_years: 15,

    revenue_items: [],
    opex_items: [],
    fixed_assets: [],
    asset_items: [],
    liability_items: [],
    equity_items: [],

    working_capital: {

        receivable_days: 30,

        payable_days: 30,

        inventory_days: 0

    }
});

    const [selectedProject,
        setSelectedProject] = useState(null);

    const [result, setResult] = useState(null);
    console.log("PROJECT FINANCE RENDER");
    console.log("Current result:", result);

    useEffect(() => {
        console.log("RESULT CHANGED:", result);
    }, [result]);
    const [activeTab, setActiveTab] = useState("income");

    useEffect(() => {

        loadProjects();

    }, []);

    const loadProjects = async () => {

        try {

            const data =
                await getProjects();

            console.log(
                "Projects:",
                data
            );

            setProjects(data);

        } catch (err) {

            console.error(err);

        }

    };

   const handleSave = async()=>{

    if(!result){

        alert("Run the model before saving.");

        return;

    }

    try{

        let saved;

        if(project.id){

            saved = await updateProject(project.id,project);

        }else{

            saved = await saveProject(project);

            setProject(prev => ({
                ...prev,
                id: saved.project_id
            }));


        }

        alert("Project Saved");

        loadProjects();

    }catch(err){

        console.error(err);

    }

}

    const handleProjectSelect =
        async (project) => {

        try {

            const fullProject =
                await getProject(project.id);

            console.log(
                "Selected:",
                fullProject
            );

            setSelectedProject(
                fullProject
            );

            setProject({

            ...project,

            ...fullProject,

            revenue_items:
                fullProject.revenue_items || [],

            opex_items:
                fullProject.opex_items || [],

            fixed_assets:
                fullProject.fixed_assets || [],

            asset_items:
                fullProject.asset_items || [],

            liability_items:
                fullProject.liability_items || [],

            equity_items:
                fullProject.equity_items || [],

            debt_drawdowns:
                fullProject.debt_drawdowns || [
                    {
                        year:1,
                        drawdown_months:1,
                        drawdown_amount:0
                    }
                ],

            moratorium_months:
                fullProject.moratorium_months ?? 0,

            repayment_frequency:
                fullProject.repayment_frequency || "Monthly",

            repayment_type:
                fullProject.repayment_type || "Equal Principal",

            interest_type:
                fullProject.interest_type || "Fixed",

            interest_capitalized:
                fullProject.interest_capitalized || false,

            working_capital:
                fullProject.working_capital || {

                    receivable_days: 30,
                    payable_days: 30,
                    inventory_days: 0

                }

        });

        } catch (err) {

            console.error(err);

        }

    };

    const handleAnalyze =
        async () => {

        try {
            console.log(JSON.stringify(project, null, 2));
          
            const analysis =
                await analyzeProject(project);
                console.log("Projection length:", analysis.projection?.length);
                console.log("Asset Schedule length:", analysis.asset_schedule?.length);
                

                console.log(
                "Analysis:",
                analysis
            );

            console.log(
                "Year 1 depreciation:",
                analysis.projection[0].depreciation
            );

            console.log(
                "Year 1 Net Fixed Assets:",
                analysis.projection[0].asset_breakdown["Net Fixed Assets"]
            );

            console.log(
                "Asset Schedule depreciation:",
                analysis.asset_schedule[0].assets[0].depreciation
            );

            setResult(analysis);

        } catch (err) {

            console.error(err);

        }

    };

    console.log("ProjectFinance rendering");
    console.log(result);

    return (

        <div className="pf-page">

            <div className="pf-container">

               {

                activeTab === "asset"

                ?

                <AssetSidebar

                    project={project}

                    setProject={setProject}

                    onAnalyze={handleAnalyze}
                     
                    onSave={handleSave}

                />

                :

                <Sidebar

                    projects={projects}

                    project={project}

                    setProject={setProject}

                    selectedProject={selectedProject}

                    onSelectProject={handleProjectSelect}

                    onAnalyze={handleAnalyze}

                    onSave={handleSave}

                />

}

                <Workspace
                    result={result}
                    project={project}
                    setProject={setProject}
                    activeTab={activeTab}
                    setActiveTab={setActiveTab}
                />

            </div>

        </div>

    );

}