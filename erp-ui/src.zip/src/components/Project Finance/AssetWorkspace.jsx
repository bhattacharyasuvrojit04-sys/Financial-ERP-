import AssetAnalysis from "./Statements/AssetAnalysis";

export default function AssetWorkspace({

    result

}){

    return(

        <div className="asset-workspace">

            <AssetAnalysis

                result={result}

            />

        </div>

    );

}