import Toolbar from "./Toolbar";
import KPIBar from "./KPIBar";
import IncomeStatement from "./Statements/IncomeStatementP";
import BalanceSheet from "./Statements/BalanceSheetP";
import CashFlow from "./Statements/CashFlowP";
import DebtSchedule from "./Statements/DebtScheduleP";
import AssetWorkspace from "./AssetWorkspace";

export default function Workspace({ result,project,setProject, activeTab, setActiveTab }) {

    console.log("========== WORKSPACE ==========");
    console.log("result =", result);
    console.log("projection =", result?.projection);
    console.log("activeTab =", activeTab);
    return (

        <div className="pf-workspace">

            <Toolbar
                activeTab={activeTab}
                setActiveTab={setActiveTab}
            />

            <KPIBar result={result} />

            {/* TEMPORARY TEST MODE */}
            {!result ? (

                <>
                    {activeTab === "income" && (
                        <div
                            style={{
                                background: "red",
                                color: "white",
                                padding: "40px",
                                fontSize: "24px"
                            }}
                        >
                            INCOME TAB IS WORKING
                        </div>
)}

                    {activeTab === "balance" && (
                        <div
                            style={{
                                padding: "20px",
                                background: "#fff",
                                border: "1px solid #ddd"
                            }}
                        >
                            BALANCE SHEET WORKING
                        </div>
                    )}

                    {activeTab === "cashflow" && (
                        <div
                            style={{
                                padding: "20px",
                                background: "#fff",
                                border: "1px solid #ddd"
                            }}
                        >
                            CASH FLOW WORKING
                        </div>
                    )}

                    {activeTab === "debt" && (
                        <div
                            style={{
                                padding: "20px",
                                background: "#fff",
                                border: "1px solid #ddd"
                            }}
                        >
                            DEBT SCHEDULE WORKING
                        </div>
                    )}

                    {activeTab === "asset" && (

                        <AssetWorkspace
                            result={result}

                        />

                    )}
                </>

            ) : (

                <>
                    {activeTab === "income" && (
    <>
        <h1 style={{ color: "red", fontSize: "40px" }}>
            COMPONENT REACHED
        </h1>

        <IncomeStatement
            data={result.projection}
        />
    </>
)}

                    {activeTab === "balance" && (
                        <BalanceSheet
                            data={result.projection}
                        />
                    )}

                    {activeTab === "cashflow" && (
                        <CashFlow
                            data={result.projection}
                        />
                    )}

                    {activeTab === "debt" && (
                        <DebtSchedule
                            data={result.debt_schedule}
                        />
                    )}

                    {activeTab === "asset" && (

                        <AssetWorkspace
                            result={result}

                        />

                    )}
                </>

            )}

        </div>

    );

}