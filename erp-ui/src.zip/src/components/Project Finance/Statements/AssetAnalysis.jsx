export default function AssetAnalysis({ result }) {

    const projection = result?.projection || [];
    const assetSchedule = result?.asset_schedule || [];

    return (

        <div className="asset-analysis">

            <h2>Fixed Asset Schedule</h2>

            {/* ---------------- Gross Block ---------------- */}

            <div className="asset-section">

                <h3>Gross Block</h3>

                <div className="asset-analysis-table">

                    <table>

                        <thead>

                            <tr>

                                <th>Description</th>

                                {

                                    projection.map(year => (

                                        <th key={year.year}>

                                            Year {year.year}

                                        </th>

                                    ))

                                }

                            </tr>

                        </thead>

                        <tbody>

                            <tr>

                                <td>Opening Gross Block</td>

                                {

                                    projection.map((row,index)=>(

                                        <td key={index}>

                                            {

                                                index===0

                                                ?0

                                                :(assetSchedule[index - 1]?.asset_breakdown?.["Gross Block"] ?? 0).toLocaleString()

                                            }

                                        </td>

                                    ))

                                }

                            </tr>

                            <tr>

                                <td>Additions</td>

                                {

                                    projection.map((row,index)=>(

                                        <td key={index}>

                                            {(row.capex_outflow ?? 0).toLocaleString()}

                                        </td>

                                    ))

                                }

                            </tr>

                            <tr>

                                <td>Disposals</td>

                                {

                                    projection.map((row,index)=>(

                                        <td key={index}>

                                            {row.asset_sale_proceeds.toLocaleString()}

                                        </td>

                                    ))

                                }

                            </tr>

                            <tr>

                                <td><b>Closing Gross Block</b></td>

                                {

                                    projection.map((row,index)=>(

                                        <td key={index}>

                                            <b>

                                                {

                                                    (assetSchedule[index]?.total_gross_block ?? 0).toLocaleString()

                                                }

                                            </b>

                                        </td>

                                    ))

                                }

                            </tr>

                        </tbody>

                    </table>

                </div>

            </div>

            {/* ---------------- Additions / Deletions ---------------- */}

            <div className="asset-section">

                <h3>Additions / Deletions</h3>

                <div className="asset-analysis-table">

                    <table>

                        <thead>

                            <tr>

                                <th>Description</th>

                                {

                                    projection.map(year=>(

                                        <th key={year.year}>

                                            Year {year.year}

                                        </th>

                                    ))

                                }

                            </tr>

                        </thead>

                        <tbody>

                            <tr>

                                <td>Purchases</td>

                                {

                                    projection.map((row,index)=>(

                                        <td key={index}>

                                            {

                                                (row.capex_outflow ?? 0).toLocaleString()

                                            }

                                        </td>

                                    ))

                                }

                            </tr>

                            <tr>

                                <td>Sales</td>

                                {

                                    projection.map((row,index)=>(

                                        <td key={index}>

                                            {

                                                row.asset_sale_proceeds.toLocaleString()

                                            }

                                        </td>

                                    ))

                                }

                            </tr>

                        </tbody>

                    </table>

                </div>

            </div>

            {/* ---------------- Depreciation ---------------- */}

            <div className="asset-section">

                <h3>Depreciation</h3>

                <div className="asset-analysis-table">

                    <table>

                        <thead>

                            <tr>

                                <th>Description</th>

                                {

                                    projection.map(year=>(

                                        <th key={year.year}>

                                            Year {year.year}

                                        </th>

                                    ))

                                }

                            </tr>

                        </thead>

                        <tbody>

                            <tr>

                                <td>Depreciation Expense</td>

                                {

                                    projection.map((row,index)=>(

                                        <td key={index}>

                                            {

                                                (assetSchedule[index]?.assets.reduce(
                                                    (sum, asset) => sum + asset.depreciation,
                                                    0
                                                )).toLocaleString()

                                            }

                                        </td>

                                    ))

                                }

                            </tr>

                        </tbody>

                    </table>

                </div>

            </div>

            {/* ---------------- Accumulated Depreciation ---------------- */}

            <div className="asset-section">

                <h3>Accumulated Depreciation</h3>

                <div className="asset-analysis-table">

                    <table>

                        <thead>

                            <tr>

                                <th>Description</th>

                                {

                                    projection.map(year=>(

                                        <th key={year.year}>

                                            Year {year.year}

                                        </th>

                                    ))

                                }

                            </tr>

                        </thead>

                        <tbody>

                            <tr>

                                <td>Opening Accumulated Depreciation</td>

                                {

                                    projection.map((row,index)=>(

                                        <td key={index}>

                                            {

                                                index===0

                                                ?0

                                                :(assetSchedule[index - 1]?.total_acc_dep ?? 0).toLocaleString()

                                            }

                                        </td>

                                    ))

                                }

                            </tr>

                            <tr>

                                <td>Current Year Depreciation</td>

                                {

                                    projection.map((row,index)=>(

                                        <td key={index}>

                                            {

                                                (row.depreciation ?? 0).toLocaleString()

                                            }

                                        </td>

                                    ))

                                }

                            </tr>

                            <tr>

                                <td><b>Closing Accumulated Depreciation</b></td>

                                {

                                    projection.map((row,index)=>(

                                        <td key={index}>

                                            <b>

                                                {

                                                   (assetSchedule[index]?.total_acc_dep ?? 0).toLocaleString()


                                                }

                                            </b>

                                        </td>

                                    ))

                                }

                            </tr>

                        </tbody>

                    </table>

                </div>

            </div>

            {/* ---------------- Net Block ---------------- */}

            <div className="asset-section">

                <h3>Net Block</h3>

                <div className="asset-analysis-table">

                    <table>

                        <thead>

                            <tr>

                                <th>Description</th>

                                {

                                    projection.map(year=>(

                                        <th key={year.year}>

                                            Year {year.year}

                                        </th>

                                    ))

                                }

                            </tr>

                        </thead>

                        <tbody>

                            <tr>

                                <td><b>Net Fixed Assets</b></td>

                                {

                                    projection.map((row,index)=>(

                                        <td key={index}>

                                            <b>

                                                {

                                                    (assetSchedule[index]?.total_net_block ?? 0).toLocaleString()



                                                }

                                            </b>

                                        </td>

                                    ))

                                }

                            </tr>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    );

}